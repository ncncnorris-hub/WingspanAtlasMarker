@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo.
echo  ============== Wingspan MOD 卸载 ==============
echo.
echo  本脚本会从【当前所在目录】删除 BepInEx 相关文件，
echo  使游戏恢复原版。请把它放在游戏根目录运行
echo  （即和 winhttp.dll、BepInEx\ 同一层）。
echo.
echo  将删除：
echo     winhttp.dll
echo     doorstop_config.ini
echo     .doorstop_version
echo     dotnet\
echo     BepInEx\
echo.
echo  注意：
echo   - 请先【完全退出 Wingspan】，否则文件被占用会删除失败。
echo   - 游戏本体与存档、成就均不受影响。
echo   - 如想保留日志，请先手动备份 BepInEx\LogOutput.log 。
echo.

choice /c YN /m "确认卸载吗 (Y=是 / N=否)"
if errorlevel 2 goto :cancel

echo.
echo  正在删除...
if exist "BepInEx"             rmdir /s /q "BepInEx"
if exist "dotnet"              rmdir /s /q "dotnet"
if exist "winhttp.dll"         del /f /q "winhttp.dll"
if exist "doorstop_config.ini" del /f /q "doorstop_config.ini"
if exist ".doorstop_version"   del /f /q ".doorstop_version"

echo.
if exist "BepInEx" (
  echo  [!] BepInEx 文件夹未能完全删除，可能游戏仍在运行。
  echo      请关闭 Wingspan 后重试，或手动删除残留。
) else (
  echo  卸载完成，游戏已恢复原版。
  echo  本脚本（卸载.bat）可自行删除。
)
echo.
pause >nul
exit /b 0

:cancel
echo.
echo  已取消，未做任何更改。
echo.
pause >nul
exit /b 0
